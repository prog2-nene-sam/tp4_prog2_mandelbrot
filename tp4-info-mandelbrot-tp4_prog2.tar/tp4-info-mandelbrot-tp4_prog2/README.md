# Mandelbrot

## Description du projet 

On va travailler sur ce TP sur l'affichage de l'[ensemble de Mandelbrot](https://en.wikipedia.org/wiki/Mandelbrot_set). Pour cela, on va utiliser un code pré-existant. 
Le but du TP sera de corriger le code de la classe `Complex` en s'aidant de tests unitaires.

## Membres du projet

THIEL Samantha, groupe 2 L2 Info
DIALLO Ndeye Néné, groupe 2 L2 Info
